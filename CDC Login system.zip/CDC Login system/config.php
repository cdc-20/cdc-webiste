<?php
$dbhost="localhost"; //hostname
$dbuser="000";  //mysql acc/ username
$dbpass="1234";  //mysql scc/ password
$dbname="test"; //mysql database name
?>